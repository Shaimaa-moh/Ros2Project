
import rclpy
from rclpy.node import Node 
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import Kill
from cmath import atan, pi, sqrt
from math import atan2, fabs

class Twister(Node):
    def __init__(self):
        super().__init__("Twister")
        self.tut1=Pose()
        self.turt_goal=Pose()
        self.next_goal=Twist()
        self.Pub1=self.create_publisher(Twist,"/turtle1/cmd_vel",10)
        self.create_subscription(Pose,"/turtle1/pose",self.position,10)
        self.create_timer(1,self.timer_call)
        self.create_subscription(Pose,"/hello_turtle1/pose",self.calculate,10)
        self.killer=self.create_client(Kill,"/kill")
        


    def position(self,obj):
        self.turt1=obj
        
    def timer_call(self):
        x=Twist()
        
        x.angular.z=self.next_goal.angular.z - self.turt1.theta
        x.linear.x=self.next_goal.linear.x 
        if (self.next_goal.linear.x)<0.1:
            request = Kill.Request()
            request.name="hello_turtle1"
            self.killer.call_async(request)
        print(f"{x.angular.z}   :  {self.next_goal.angular.z}")
        self.Pub1.publish(x)

    def calculate(self,dist):
        self.turt_goal.x=dist.x-self.turt1.x
        self.turt_goal.y=dist.y-self.turt1.y
        self.next_goal.linear.x= sqrt(pow (self.turt_goal.x,2)+ pow (self.turt_goal.y,2)).real
        self.next_goal.angular.z=atan2(self.turt_goal.y,self.turt_goal.x)
    
def main (args=None):
    rclpy.init(args=args)
    node1=Twister()
    rclpy.spin(node1)
    rclpy.shutdown()
main()
