from re import L
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose


class my_node(Node):
    def __init__(self):
        print("Node Created")
        super().__init__("turtle")
        self.pub1=self.create_publisher(Twist,"/turtle1/cmd_vel",10)
        self.create_subscription(Pose,"/turtle1/pose",self.sub_call,10)
        self.create_timer(1,self.timer_call)
        

    def timer_call(self):
        x=Twist()
        x.linear.x=1.0
        x.angular.z=1.0
        self.pub1.publish(x)
    def sub_call(self,msg):
        x=Pose()
        print(f"x is :{msg.x} ,y is :{msg.y} ,theta is {msg.theta} ")


def main(args=None):
    rclpy.init(args=args)
    node=my_node()
    rclpy.spin(node)
    

if __name__=="__main__":
    main()