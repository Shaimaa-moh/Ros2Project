import rclpy
from rclpy.node import Node
from turtlesim.srv import Spawn
from turtlesim.msg import Pose
from random import *
class my_server(Node):
    def __init__(self):
        super().__init__("Client_OOP_node")
        self.client=self.create_client(Spawn,"/spawn")
        self.service_client(uniform(1, 10),uniform(1, 10),1.0,"hello_turtle1")
        self.create_subscription(Pose,"/hello_turtle1/pose",self.sub_call,10)
        
    def service_client(self,x,y,theta,turtle_name):
        
        while self.client.wait_for_service(1)==False:
            self.get_logger().warn("wating for server")

        request=Spawn.Request()
        request.x = x 
        request.y = y
        request.theta = theta
        request.name = turtle_name
        futur_obj=self.client.call_async(request)

        futur_obj.add_done_callback(self.future_call)

    def future_call(self,future_msg):

        print(f"Response is : {future_msg.result().name}")

    def sub_call(self,msg):
        x=Pose()
        print(f"x is :{msg.x} ,y is :{msg.y} ,theta is {msg.theta} ")

def main (args=None):
    rclpy.init(args=args)
    node1=my_server()
    rclpy.spin(node1)
    rclpy.shutdown()

if __name__ == "__main__":
    main()