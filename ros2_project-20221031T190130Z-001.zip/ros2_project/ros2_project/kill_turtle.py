import rclpy
from rclpy.node import Node
from turtlesim.srv import Kill

class my_server(Node):
    def __init__(self):
        super().__init__("Client_OOP_node")
        self.client=self.create_client(Kill,"/kill")
        self.service_client("hello_turtle1")
        

    def service_client(self,turtle_name):
        
        while self.client.wait_for_service(1)==False:
            self.get_logger().warn("wating for server")

        request=Kill.Request()
        request.name = turtle_name
        futur_obj=self.client.call_async(request)
       
def main (args=None):
    rclpy.init(args=args)
    node1=my_server()
    rclpy.spin(node1)
    rclpy.shutdown()

if __name__ == "__main__":
    main()