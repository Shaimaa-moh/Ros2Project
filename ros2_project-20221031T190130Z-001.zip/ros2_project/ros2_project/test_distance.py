import math
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import kill_turtle
from random import *
from math import pow, atan2, sqrt      
import client_spawn
import kill_turtle
import publish_turtle
class my_destination_node(Node):
    def __init__(self):
        print("Go_to_destination")
        super().__init__("turtle_go_goal")
        self.pub1=self.create_publisher(Twist,"/turtle1/cmd_vel",10)
        self.pub2=self.create_subscription(Pose,"/turtle1/pose",self.sub_call,10)
        #self.goal=self.create_subscription(Pose,"/hello_turtle1/pose",self.sub_call2,10)
        self.create_timer(1,self.move2goal)  
        #client_spawn.my_server()
        self.pose=Pose()
        self.tpose=Pose()
        self.rate = self.create_rate(10)
        #self.flag=False

    def sub_call(self,data):   
        self.pose.x=data.x
        self.pose.y=data.y
        self.pose.theta=data.theta
        msg='x:{:.3f} , y :{:.3f} , theta :{:.3f}'.format(data.x,data.y,data.theta)
        #self.get_logger().info(msg)
        
    def euclidean_distance(self, goal_pose):
        
        return sqrt(pow((goal_pose.x - self.pose.x), 2) +
                    pow((goal_pose.y - self.pose.y), 2))

    def linear_velocity(self, goal_pose, constant=1.5):
        
        return constant * self.euclidean_distance(goal_pose)

    def rotating_angle(self, goal_pose):
        
        return atan2(goal_pose.y - self.pose.y, goal_pose.x - self.pose.x)

    def angular_velocity(self, goal_pose, constant=6):
        
        return constant * (self.rotating_angle(goal_pose) - self.pose.theta)

    def move2goal(self):
        goal_pose = Pose()
        goal_pose.x = self.tpose.x
        goal_pose.y = self.tpose.y
        print(goal_pose.x,goal_pose.y)
        distance_tolerance = 0.001

        velocity_msg = Twist()
        #x=client_spawn.my_server()
        # while achieving spawning and creating more turtles
        #while x.service_client(self.tpose.x,self.tpose.y,self.tpose.theta,'hello_turtle1'):
            #if self.euclidean_distance(goal_pose)==0.0:
                # call the kill process
                #x=kill_turtle.my_server()
                #x.service_client('hello_turtle1')
                #also call clear topic to remove the white path
            #else:
                #y=publish_turtle.my_node()
               
                #y.timer_call()
                # continue moving & searching
        while self.euclidean_distance(goal_pose) >= distance_tolerance:
            
            velocity_msg.linear.x = self.linear_velocity(goal_pose)
            velocity_msg.linear.y = 0.0
            velocity_msg.linear.z = 0.0
            velocity_msg.angular.x = 0.0
            velocity_msg.angular.y = 0.0
            velocity_msg.angular.z = self.angular_velocity(goal_pose)
            self.pub1.publish(velocity_msg)

            #  desired rate.
            self.rate.sleep()

        # Stopping our robot after spanning is over.
        else:
            velocity_msg.linear.x = 0.0
            velocity_msg.angular.z = 0.0
            self.pub1.publish(velocity_msg)
        # If we press control + C, the node will stop   
        # rclpy.spin(Node)    
def main(args=None):
    rclpy.init(args=args)
    node=my_destination_node()
    node.move2goal()
    rclpy.spin(node)
    rclpy.shutdown()
if __name__ == "__main__":
    main()